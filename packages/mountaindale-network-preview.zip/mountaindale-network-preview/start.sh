#!/bin/sh
cd "$(dirname "$0")"
echo "Open http://127.0.0.1:8765/network/"
exec python3 -m http.server 8765 --bind 127.0.0.1
