Mountaindale network map — standalone public preview

This package is the public viewer only. It is not a git checkout and it contains no private inventory, notes, or plans.

Start
1. Install Python 3.
2. From this folder run ./start.sh (macOS or Linux) or start.cmd (Windows).
3. Open http://127.0.0.1:8765/network/

The page is static. Cable lengths are approximate, measured along the drawn route, in feet.

SHA256SUMS lists every file in this folder except itself. The zip file's own hash is printed when the package is built.
